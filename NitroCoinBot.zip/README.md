# NitroCoinBot

Bot for NitroCoin game project.